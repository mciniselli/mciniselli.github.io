from file_manager import FileManager
import string

import utils.settings as settings


class Post:
    def __init__(self, Id, PostTypeId, ParentId, Score, Body, OwnerUserId, Title, Tags, AnswerCount):
        self.Id = Id
        self.Type = PostTypeId  # 1 = Question, 2 = Answer
        self.ParentId = ParentId
        self.Score = Score
        self.Text = Body
        self.UserId = OwnerUserId
        self.Title = Title
        self.Tags = Tags
        self.NumAnswers = AnswerCount
        self.log = settings.logger

    def print_post(self, is_question=True):
        if is_question:
            self.log.info("Id: {}, Title: {}".format(self.Id, self.Title))
            self.log.info("Score: {}, Num Answers: {}".format(self.Score, self.NumAnswers))
        else:
            self.log.info("Id: {}, Score: {}".format(self.Id, self.Score))


class Discussion:
    def __init__(self, question):
        self.question = question
        self.answers = list()
        self.DiscussionId = question.Id

        self.Url = self.return_url_discussion()
        self.log = settings.logger

    def return_url_discussion(self):
        '''
        return the url of the discussion
        '''
        base_url = "https://stackoverflow.com/questions"

        title = self.question.Title.translate(str.maketrans('', '', string.punctuation)).lower().replace(" ", "-")

        return "{}/{}/{}".format(base_url, str(self.DiscussionId), title)

    def add_answer(self, answer):
        '''
        add an answer to the discussion
        '''
        self.answers.append(answer)

    def print_discussion(self):
        '''
        print all information about the discussion
        '''
        self.log.info("______________________________")
        self.log.info("Discussion URL: {}".format(self.Url))

        self.question.print_post(True)
        for i, a in enumerate(self.answers):
            self.log.info("Answer {}".format(i + 1))
            a.print_post(False)

        self.log.info("______________________________")

    def return_body(self):
        '''
        return the body (of the question and all answers) + the titles
        '''
        bodies = list()

        title = self.question.Title
        # remove the punctuation from the title (sometimes there were <script> tags in the title
        # and this generated compiling errors
        chars_to_remove = str(string.punctuation)

        for a in list(chars_to_remove):
            title = title.replace(a, " ")

        bodies.append("<p>{}</p>".format(title))
        bodies.append(self.question.Text)
        for answer in self.answers:
            bodies.append("<p>{}</p>".format(answer.Title))
            bodies.append(answer.Text)

        return " ".join(bodies)

    def return_score(self):
        '''
        return the score of each question (one for each discussion)
        '''
        return self.question.Score


class DiscussionList:
    def __init__(self, questions, answers, separator):
        '''
        class for the list of all discussions
        '''
        self.questions = questions
        self.answers = answers
        self.separator = separator
        self.discussions = dict()
        self.bodies = dict()
        self.scores = dict()
        self.log = settings.logger

    def add_discussion(self, question):
        '''
        add a discussion to discussion dictionary
        '''
        if question.Id in self.discussions.keys():
            self.log.info("ERROR, DUPLICATE DISCUSSION")
        else:
            self.discussions[question.Id] = Discussion(question)

    def add_answer(self, answer):
        '''
        add a answer to the correct question
        '''
        if answer.ParentId not in self.discussions.keys():
            self.log.info("ERROR, QUESTION {} NOT FOUND".format(answer.ParentId))

        else:
            self.discussions[answer.ParentId].add_answer(answer)

    def create_post_arguments(self, question):
        p = question.split(self.separator)
        return [p[0], p[1], p[2], p[4], p[5], p[6], p[7], p[8], p[9]]

    def create_list_of_discussions(self):
        '''
        create the list of discussion, keeping track of all important fields
        '''
        # ["Id", "PostTypeId", "ParentId", "CreationDate", "Score", "Body", "OwnerUserId", "Title",
        #                   "Tags", "AnswerCount", "CommentCount", "ClosedDate"]

        self.log.info("START CREATING DISCUSSIONS")

        for q in self.questions:
            p = Post(*self.create_post_arguments(q))
            self.add_discussion(p)

        for a in self.answers:
            p = Post(*self.create_post_arguments(a))
            self.add_answer(p)

        self.create_bodies_and_scores()

    def create_bodies_and_scores(self):
        '''
        create body and scores object
        '''
        self.log.info("START CREATING BODIES")

        self.create_bodies()

        self.log.info("END CREATING BODIES")

        self.log.info("START CREATING SCORES")
        self.create_scores()

        self.log.info("END CREATING SCORES")

    def print_discussions(self):
        self.log.info("PRINT DISCUSSIONS")
        for k in self.discussions.keys():
            self.discussions[k].print_discussion()

    def create_bodies(self):
        '''
        create a dictionary with all the bodies
        '''
        dict_bodies = dict()

        for k in self.discussions.keys():
            body = self.discussions[k].return_body()
            dict_bodies[self.discussions[k].DiscussionId] = body

        self.bodies = dict_bodies

    def create_scores(self):
        '''
        crete a dict with all scores for each question
        '''
        dict_scores = dict()
        for k in self.discussions.keys():
            score = self.discussions[k].return_score()
            dict_scores[self.discussions[k].DiscussionId] = float(score)

        self.scores = dict_scores
