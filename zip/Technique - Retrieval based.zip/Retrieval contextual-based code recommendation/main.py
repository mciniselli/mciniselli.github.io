import argparse

import os

import time
import nltk

from similarities.textual_similarity import TextualSimilarity

from create_discussions import CreateDiscussions

from similarities.api_method_similarity import ApiMethodSimilarity

from similarities.question_score import QuestionScore

from similarities.reputation import Reputation

from users import *

from similarities.tag_similarity import TagSimilarity
from datetime import datetime

from utils.settings import init_global

import utils.settings as settings

def create_data(questions, answers, users):
    '''
    create the file with discussion tokens (with all files)
    '''
    cd = CreateDiscussions(questions, answers)
    cd.create_discussions_list()

    separator = "|!--!|"

    u = UsersList(users, separator)
    u.create_list_of_users()


    return cd, u

def compute_similarity(discussions_class, users_class, query_folder, idf_folder, save_or_load_idf, discussion_tokens_folder, save_or_load_discussion_tokens, api_folder, save_or_load_api, tag_folder, save_or_load_tag, avg_score, avg_reputation, weights_string, num_suggestions):
    '''
    Compute the similarity for each query in @query_folder
    The similarity is made up by:
    1. cosine similarity. The computation of tf-idf require a huge amount of time, so we can save it into @idf_folder
    You can choose to save it (@save_or_load = "save") or load it (@save_or_load = "load")
    2. API methods similarity
    '''
    discussions = discussions_class.discussions
    bodies = discussions_class.bodies
    scores=discussions_class.scores
    reputations=users_class.user_reputations

    weights=weights_string.split(",")
    weights=[float(w.strip()) for w in weights]

    settings.logger.info("START INITIALIZATION TEXTUAL SIMILARITY")

    # initialize textual similarity
    t = TextualSimilarity(discussions, bodies, idf_folder, save_or_load_idf, discussion_tokens_folder, save_or_load_discussion_tokens)
    t.initialize_textual_similarity()

    settings.logger.info("START INITIALIZATION API METHOD SIMILARITY")

    # initialize API method similarity
    a=ApiMethodSimilarity(discussions, bodies, api_folder, save_or_load_api)
    a.initialize_api_method_similarity()

    settings.logger.info("START INITIALIZATION QUESTION SCORE SIMILARITY")

    # initialize question score
    q = QuestionScore(avg_score, scores)
    q.initialize_question_scores()

    settings.logger.info("START INITIALIZATION REPUTATION SIMILARITY")

    # initialize user reputation
    r = Reputation(avg_reputation, reputations, discussions)
    r.initialize_user_reputation()

    settings.logger.info("START INITIALIZATION TAG SIMILARITY")


    tag=TagSimilarity(discussions, bodies, tag_folder, save_or_load_tag)
    tag.initialize_tag_similarity()

    # compute similarity for each query

    query_files = os.listdir(query_folder)
    python_query_files = [f for f in query_files if ".py" in f]

    for file in python_query_files:
        file_name = os.path.join(query_folder, file)
        settings.logger.info("PROCESSING FILE {}".format(file_name))

        settings.logger.info("START COMPUTATION TEXTUAL SIMILARITY")

        textual_similarity=t.compute_textual_similarity(file_name)
        settings.logger.info("START COMPUTATION API METHOD SIMILARITY")

        api_method_similarity=a.compute_api_method_similarity(file_name)
        settings.logger.info("START COMPUTATION QUESTION SCORE SIMILARITY")

        question_score=q.compute_question_scores()
        settings.logger.info("START COMPUTATION REPUTATION SIMILARITY")

        user_reputation=r.compute_user_reputation()
        settings.logger.info("START COMPUTATION TAG SIMILARITY")

        tag_similarity=tag.compute_tag_similarity(file_name)
        settings.logger.info("START COMPUTATION WEIGHTED SIMILARITY")

        weighted_similarity(textual_similarity, api_method_similarity, question_score, user_reputation, tag_similarity, discussions, weights, num_suggestions)
        settings.logger.info("FINISHED COMPUTATION")

def weighted_similarity(textual_similarity, api_method_similarity, question_score, user_reputation, tag_similarity, discussions, weights, num_suggestions):
    '''
    compute the weighted similarity using the weights suggested in Ponzanelli et al
    '''
    # all the keys are the same
    weighted_similarity_dict=dict()

    for k in textual_similarity.keys():
        weighted_similarity_dict[k]=0

    for k in textual_similarity.keys():
        curr_similarity=weights[0]*textual_similarity[k]
        curr_similarity+=weights[1]*api_method_similarity[k]
        curr_similarity+=weights[2]*question_score[k]
        curr_similarity+=weights[3]*user_reputation[k]
        curr_similarity+=weights[4]*tag_similarity[k]
        weighted_similarity_dict[k]= curr_similarity

    extract_top_k_discussions(weighted_similarity_dict, textual_similarity, api_method_similarity, question_score, user_reputation, tag_similarity, discussions, num_suggestions)

def extract_top_k_discussions(weighted_similarity_dict, textual_similarity, api_method_similarity, question_score, user_reputation, tag_similarity, discussions, k):
    '''
    extract the top k discussion with the highest score
    '''
    sorted_dict={k: v for k, v in sorted(weighted_similarity_dict.items(), key=lambda item: item[1], reverse=True)}

    best_keys=list(sorted_dict.keys())[:k]

    for key in best_keys:
        print("key: {}, score: {}".format(key, sorted_dict[key]))
        settings.logger.info("key: {}, score: {}".format(key, sorted_dict[key]))
        settings.logger.info("textual similarity: {}".format(textual_similarity[key]))
        settings.logger.info("api method similarity: {}".format(api_method_similarity[key]))
        settings.logger.info("question score: {}".format(question_score[key]))
        settings.logger.info("user reputation: {}".format(user_reputation[key]))
        settings.logger.info("tag similarity: {}".format(tag_similarity[key]))
        settings.logger.info("____ print discussion ____")

        discussions[key].print_discussion()

    for key in best_keys:
        print(discussions[key].Url)
        settings.logger.info(discussions[key].Url)


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("-questions", "--questions", type=str,
                        default=None,
                        help="Questions file")

    parser.add_argument("-answers", "--answers", type=str,
                        default=None,
                        help="Answers file")

    parser.add_argument("-users", "--users", type=str,
                        default=None,
                        help="Users file")

    parser.add_argument("-scores", "--scores", type=str,
                        default=None,
                        help="Scores file")

    parser.add_argument("-reputations", "--reputations", type=str,
                        default=None,
                        help="Reputations file")

    parser.add_argument("-query", "--query", type=str,
                        default=None,
                        help="Query folder that contains a list of task (file python)")

    parser.add_argument("-score", "--score", type=float,
                        default=None,
                        help="Average score among all the authors of questions")

    parser.add_argument("-reputation", "--reputation", type=float,
                        default=None,
                        help="Average reputation among all the users")


    parser.add_argument("-idf", "--idf", type=str,
                        default=None,
                        help="Idf folder path where idf.json and count_idf.json will be saved/loaded (depending of @save_or_load_idf)")

    parser.add_argument("-save_or_load_idf", "--save_or_load_idf", type=str,
                        default=None,
                        help="save if you want to save idf in @idf path,"
                             " load if you want to load it")

    parser.add_argument("-discussion_tokens", "--discussion_tokens", type=str,
                        default=None,
                        help="discussion tokens folder path where discussion_tokens.json will be saved/loaded (depending of @save_or_load_discussion_tokens)")

    parser.add_argument("-save_or_load_discussion_tokens", "--save_or_load_discussion_tokens", type=str,
                        default=None,
                        help="save if you want to save discussion_tokens in @discussion_tokens path,"
                             " load if you want to load it")

    parser.add_argument("-api", "--api", type=str,
                        default=None,
                        help="Api methods folder path where api_methods.json will be saved/loaded (depending of @save_or_load_api)")

    parser.add_argument("-save_or_load_api", "--save_or_load_api", type=str,
                        default=None,
                        help="save if you want to save api_methods.json in @api path,"
                             " load if you want to load it")

    parser.add_argument("-tag", "--tag", type=str,
                        default=None,
                        help="Tag folder path where tags.json will be saved/loaded (depending of @save_or_load_tag)")

    parser.add_argument("-save_or_load_tag", "--save_or_load_tag", type=str,
                        default=None,
                        help="save if you want to save tags.json in @tag path,"
                             " load if you want to load it")

    parser.add_argument("-download", "--download", action="store_true",
                        help="Download stopwords list and punkt")

    parser.add_argument("-weights", "--weights", type=str,
                        default=None, help="weights in float for each metric, comma separated")

    parser.add_argument("-num_suggestions", "--num_suggestions", type=int,
                        default=10,
                        help="Download stopwords list and punkt")

    args = parser.parse_args()

    init_global()

    print("MAKE SURE THAT QUERY FILES ARE CLEANED (WITHOUT TASK DESCRIPTION)")
    settings.logger.info("MAKE SURE THAT QUERY FILES ARE CLEANED (WITHOUT TASK DESCRIPTION)")
    time.sleep(1)

    # download stopwords and punctuation
    if args.download:
        nltk.download('stopwords')
        nltk.download('punkt')

    # if you want to have a look at the average global score and reputation, you can run the following two lines of code
    # gv=GlobalValue(args.scores, args.reputations)
    # gv.compute_global_values()

    cd, u = create_data(args.questions, args.answers, args.users)

    compute_similarity(cd, u, args.query, args.idf, args.save_or_load_idf, args.discussion_tokens,
                       args.save_or_load_discussion_tokens, args.api, args.save_or_load_api, args.tag,
                       args.save_or_load_tag, args.score, args.reputation, args.weights, args.num_suggestions)

    settings.logger.info(datetime.now())


if __name__ == "__main__":
    main()

