# Stack Overflow database schema

Here you can find a short description of the database: https://www.brentozar.com/archive/2018/02/gentle-introduction-stack-overflow-schema/
Here you can find all the fields: https://meta.stackexchange.com/questions/2677/database-schema-documentation-for-the-public-data-dump-and-sede

We saved only the important fields, the schema for all the CSV files is:

Questions
+-----------------------+--------------+------+-----+---------+-------+
| Field                 | Type         | Null | Key | Default | Extra |
+-----------------------+--------------+------+-----+---------+-------+
| Id                    | int          | NO   | PRI | NULL    |       |
| PostTypeId            | tinyint      | NO   |     | NULL    |       |
| ParentId              | int          | YES  | MUL | NULL    |       |
| CreationDate          | datetime     | NO   |     | NULL    |       |
| Score                 | int          | YES  |     | NULL    |       |
| Body                  | longtext     | YES  |     | NULL    |       |
| OwnerUserId           | int          | YES  | MUL | NULL    |       |
| Title                 | varchar(256) | YES  |     | NULL    |       |
| Tags                  | varchar(256) | YES  |     | NULL    |       |
| AnswerCount           | int          | YES  |     | 0       |       |
| CommentCount          | int          | YES  |     | 0       |       |
| ClosedDate            | datetime     | YES  |     | NULL    |       |
+-----------------------+--------------+------+-----+---------+-------+

Answers
+-----------------------+--------------+------+-----+---------+-------+
| Field                 | Type         | Null | Key | Default | Extra |
+-----------------------+--------------+------+-----+---------+-------+
| Id                    | int          | NO   | PRI | NULL    |       |
| PostTypeId            | tinyint      | NO   |     | NULL    |       |
| ParentId              | int          | YES  | MUL | NULL    |       |
| CreationDate          | datetime     | NO   |     | NULL    |       |
| Score                 | int          | YES  |     | NULL    |       |
| Body                  | longtext     | YES  |     | NULL    |       |
| OwnerUserId           | int          | YES  | MUL | NULL    |       |
| Title                 | varchar(256) | YES  |     | NULL    |       |
| Tags                  | varchar(256) | YES  |     | NULL    |       |
| AnswerCount           | int          | YES  |     | 0       |       |
| CommentCount          | int          | YES  |     | 0       |       |
| ClosedDate            | datetime     | YES  |     | NULL    |       |
+-----------------------+--------------+------+-----+---------+-------+

Users
+-----------------+--------------+------+-----+---------+-------+
| Field           | Type         | Null | Key | Default | Extra |
+-----------------+--------------+------+-----+---------+-------+
| Id              | int          | NO   | PRI | NULL    |       |
| Reputation      | int          | NO   |     | NULL    |       |
| CreationDate    | datetime     | YES  |     | NULL    |       |
| DisplayName     | varchar(40)  | YES  |     | NULL    |       |
| Views           | int          | YES  |     | 0       |       |
| UpVotes         | int          | YES  |     | NULL    |       |
| DownVotes       | int          | YES  |     | NULL    |       |
| Age             | int          | YES  |     | NULL    |       |
+-----------------+--------------+------+-----+---------+-------+

Reputations

One single column (Reputation) with the reputation of each user

Scores

One single column (Score) with the score of each question