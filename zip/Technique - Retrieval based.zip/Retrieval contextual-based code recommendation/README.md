# Ranking discussions

In this step we computed the similarity between each task given and each discussion.
A discussion is formed by the **title** and the body of the question and of the all answers
Each answer is related to a question (question.Id = answer.ParentId)
We used create_discussion class to create the list of all the discussions.
Then we computed each of the metrics highlighted in `Mining StackOverflow to turn the IDE into a self-confident programming prompter` by Ponzanelli et al.

## Before to start
The query file provided does not contain the part of code we want to complete.
In order for the python parser to parse it, it must be compilable.
You have to add `'this line has to be removed'` string instead of the part of code you have removed.
This string is not considered for the metric computation.
The code must be compilable, so if adding this string there should be compilation error you need to proceed as follows (adding some simple tokens that make the code compilable and tell the tool which tool it does not have to consider).

ORIGINAL CODE
while left_count <MASK>
	
NEW CODE
while left_count in numbers:
	'this line has to be removed|||TOKEN:in|$|numbers|$|:'

So you added a compilable part (in, numbers, :) but you added them in the following line (||| is the separator between the string used in the general case and the other part
You add TOKEN: and then each token you added separated by |$|
Keep attention to add a simple part (no API, no tags) because they are not removed from API and tag similarity!

## Textual similarity

The first metric to be computed is textual similarity.
Given the bodies (formed by the title of the discussion and all the bodies of question and answers) the following operation are computed:
1. Parsing with a HTML parser. The code is given to BeautifulSoup in order to be parsed
2. Code removal. All code blocks are removed. A code block is formed by two nested tags `<pre><code> code here </code></pre>` (sometimes pre could have some attributes).
3. Tag removal. Are HTML tags are removed
4. punctuation removal. All punctuation is removed from the plain text
5. Stopwords and keywords removal. Using **nltk** we removed all English stopwords. We also removed all python keywords
6. Split compound tokens. We splitted compound tokens, splitting whether there is a digit or an underscore (e.g "hello0new_world" => ["hello", "new", "world"])
7. Stemming. We apply Snowball Stemmer (Porter 2)

The result is the list of tokens of the discussion that we have to compare to each task.
We processed each task. We saved all tasks in a folder (keep attention to remove the task description at the beginning).
Then we read each task and applied point 4 to 7 as before to process the task.

The comparison between them is done via cosine similarity between tf-idf. For further information see `'https://janav.wordpress.com/2013/10/27/tf-idf-and-cosine-similarity/'`
Computing idf is very expensive, so we gave the possibility to save and load idf-vector.
You can specify the path of idf json file in `--idf` argument. If you set `save_or_load_idf` to "save" you're going to compute idf and save it in the specified file path. If you set it to "load", you're going to read the idf file from the specified path without computing it.

## Api method similarity

We want to compute the similarity between API used in the task and API used in the each discussion.
We used `ast` module to extract the list of API calls from each python snippet.

Then we extracted all API calls from all the discussions (we considered only the code blocks and we use try catch, if the code is not python)
We removed all duplicates and we computed the percentage of methods in query that are present in each discussion.

## Question score
For this metric, we need to know the global score for questions in stackoverflow.

We considered all questions where there is at least a vote (data are saved in Score table)
You can see details about other metrics running GlobalValue class but it's useless

mysql> select avg(Score) from Scores;
+------------+
| avg(Score) |
+------------+
|     3.6562 |
+------------+


## User reputation

We need to know the average reputation of the users that posted at least one question or one answer.
You can see details about other metrics running GlobalValue class but it's useless

mysql> select avg(Reputation) from Reputations;
+-----------------+
| avg(Reputation) |
+-----------------+
|        309.7772 |
+-----------------+

Some users who posted a question were deleted, so we didn't have reputation for them in Users table.
We excluded all questions and answers of these users

## Tag similarity

We compute tag similarity in the following way:
1. we extracted all the tags from the import statements in query snippet (splitting them into subwords if they contain a symbol or a digit) excluding them if the length is of 1 char and removing duplicates (if we had `from os import listdir` we extracted `[os, listdir]`)
2. we extracted the Tags from the question in Stackoverflow (splittig them into subwords if they contain a symbol or a digit), excluding them if the length is of 1 char and removing duplicates.
We returned the percentage of query tags contained in the question Tags

## Compute the similarity

Following the weights described in the reference paper, we computed the similarity using the following weights for each contributor:
```
Textual Similarity 0.32
API Methods Similarity 0.30
Question Score 0.07 
User Reputation 0.13
Tags Similarity 0.18
```

We ranked the result returning the top k best fitting.

## How to run the code

1. save the  in a chosen folder the csv files that you can find [here](<LINK> Omitted for double blind review). You can also create your own files, read the README_Database.md file for further information
2. prepare the files you want to find the similar discussions from and save them in a specific folder. Read the section `Before to start` to understand how to prepare the file. The tool will process all the files in this folder.
3. copy all the files in `Retrieval contextual-based code recommendation` in a new folder and there create the environment `python3.7 -m venv venv`
4. enter in the environment `source venv/bin/activate`
5. install the dependencies `pip install -r requirements.txt`
6. run the following command:
```
python3 main.py --questions <path to questions.csv file> --answers <path to answers.csv file> --users <path to users.csv file> --reputations <path to reputations.csv file> --scores <path to scores.csv file> --idf <folder in which you want to save idf.json file> --save_or_load_idf save --discussion_tokens <folder in which you want to save discussion_tokens.json file> --save_or_load_discussion_tokens save  --api <folder in which you want to save api_methods.json file> --save_or_load_api save --tag <folder in which you want to save tags.json file> --save_or_load_tag save --query <folder where there are the files prepared as described before to find the most similar discussions> --score  3.66  -reputation 309.78 --weights "0.32,0.30,0.07,0.13,0.18"
```
where:
1. you can choose to save or load the temporary file we're creating to speed up the procedure using `save` or `load`
2. for score and reputatation you can find above how we defined them
3. we used the weights from [Ponzanelli et al paper](https://dl.acm.org/doi/pdf/10.1145/2597073.2597077)

Once that you followed these steps (it may require a few hours the first time for saving temporary files) you can find the logger.log file in the same folder of the main.py file.
It contains the top 10 related discussion.
You can find `PROCESSING FILE <name of the file>` that indicate which file it is processing
then you can find a list of discussion with this format:
```
key: 6670029, score: 0.5182504972626829
textual similarity: 0.5726578039459918
api method similarity: 0.25
question score: 0.999999999999508
user reputation: 1.0
tag similarity: 0.3333333333333333
____ print discussion ____
______________________________
Discussion URL: https://stackoverflow.com/questions/6670029/can-i-force-python3s-oswalk-to-visit-directories-in-alphabetical-order-how
2021-07-21 02:39:59,434 - LOGGER - INFO - Id: 6670029, Title: Can I force python3's os.walk to visit directories in alphabetical order? how?
2021-07-21 02:39:59,434 - LOGGER - INFO - Score: 32, Num Answers: 3
2021-07-21 02:39:59,434 - LOGGER - INFO - Answer 1
2021-07-21 02:39:59,434 - LOGGER - INFO - Id: 6670926, Score: 42
2021-07-21 02:39:59,434 - LOGGER - INFO - Answer 2
2021-07-21 02:39:59,434 - LOGGER - INFO - Id: 48139219, Score: 6
2021-07-21 02:39:59,434 - LOGGER - INFO - Answer 3
2021-07-21 02:39:59,434 - LOGGER - INFO - Id: 51390492, Score: 1
```