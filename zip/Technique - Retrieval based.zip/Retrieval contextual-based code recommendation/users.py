
from file_manager import FileManager
import numpy as np

import utils.settings as settings

class User:
    def __init__(self, Id, Reputation, CreationDate, DisplayName, Views, UpVotes, DownVotes, Age):
        '''
        user class with all his attributes
        '''
        self.Id = Id
        self.Reputation = Reputation
        self.CreationDate = CreationDate
        self.DisplayName = DisplayName
        self.Views = Views
        self.UpVotes = UpVotes
        self.DownVotes = DownVotes
        self.Age = Age
        self.log = settings.logger

    def print_users(self):
        self.log.info("User Id: {}, Reputation: {}, Name: {}".format(self.Id, self.Reputation, self.DisplayName))
        self.log.info("UpVotes: {}, DownVotes: {}".format(self.UpVotes, self.DownVotes))

    def return_reputation(self):
        return self.Reputation

class UsersList:
    def __init__(self, users_file, separator):
        '''
        class for the list of all users
        '''
        self.users_file = users_file
        self.separator = separator
        self.dict_users=None
        self.user_reputations=None
        self.log=settings.logger

    def create_list_of_users(self):
        '''
        create the list of all users reading the import file
        '''
        fields_users = ["Id", "Reputation", "CreationDate", "DisplayName", "Views", "UpVotes", "DownVotes", "Age"]

        # read users file
        f = FileManager(self.users_file)
        f.open_file_csv("r", fields_users)
        users = f.read_csv_list(separator=self.separator)
        f.close_file()

        self.log.info("Read {} users".format(len(users)))

        from datetime import datetime
        self.log.info("START CREATING USERS")

        dict_users=dict()

        for user in users:
            u = User(*self.create_users_arguments(user))
            dict_users[u.Id] = u

        self.dict_users = dict_users

        self.create_reputation()

        from datetime import datetime
        self.log.info("END CREATING USERS")

    def create_users_arguments(self, user):
        p = user.split(self.separator)
        return [p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]]


    def create_reputation(self):
        '''
        for each user it contains his reputation
        '''
        user_reputations = dict()
        list_rep=list()
        for k in self.dict_users.keys():
            reputation = self.dict_users[k].return_reputation()
            list_rep.append(float(reputation))
            user_reputations[self.dict_users[k].Id] = float(reputation)

        self.user_reputations = user_reputations


