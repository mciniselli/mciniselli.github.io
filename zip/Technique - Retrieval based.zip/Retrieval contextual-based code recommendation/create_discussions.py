from file_manager import FileManager

from discussions import DiscussionList

import utils.settings as settings

class CreateDiscussions:
    def __init__(self, questions_file, answers_file):
        '''
        wrapper class for discussions creation
        '''
        self.discussions = dict()
        self.bodies = dict()
        self.scores = dict
        self.questions_file = questions_file
        self.answers_file = answers_file
        self.log = settings.logger

    def create_discussions_list(self):
        '''
        read questions and answers files and create discussions, bodies and scores objects
        '''
        # read questions file

        fields_questions = ["Id", "PostTypeId", "ParentId", "CreationDate", "Score", "Body", "OwnerUserId", "Title",
                            "Tags", "AnswerCount", "CommentCount", "ClosedDate"]


        separator = "|!--!|"

        f = FileManager(self.questions_file)
        f.open_file_csv("r", fields_questions)
        questions = f.read_csv_list(separator=separator)
        f.close_file()

        # read answers file
        f = FileManager(self.answers_file)
        f.open_file_csv("r", fields_questions)
        answers = f.read_csv_list(separator=separator)
        f.close_file()

        self.log.info("Read {} questions and {} answers".format(len(questions), len(answers)))

        dl = DiscussionList(questions, answers, separator)
        dl.create_list_of_discussions()

        # dl.print_discussions()

        self.discussions = dl.discussions
        self.bodies = dl.bodies
        self.scores = dl.scores