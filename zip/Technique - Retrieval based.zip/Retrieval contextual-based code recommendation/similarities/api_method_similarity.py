import ast

from bs4 import BeautifulSoup

import os

import json

from file_manager import FileManager

import utils.settings as settings


class CallCollector(ast.NodeVisitor):
    '''
    Class found online to collect all methods calls
    '''

    def __init__(self):
        self.calls = []
        self._current = []
        self._in_call = False

    def visit_Call(self, node):
        self._current = []
        self._in_call = True
        self.generic_visit(node)

    def visit_Attribute(self, node):
        if self._in_call:
            self._current.append(node.attr)
        self.generic_visit(node)

    def visit_Name(self, node):
        if self._in_call:
            self._current.append(node.id)
            self.calls.append('.'.join(self._current[::-1]))
            # Reset the state
            self._current = []
            self._in_call = False
        self.generic_visit(node)


class ApiMethodSimilarity:
    def __init__(self, discussions, bodies, api_folder, save_or_load_api):
        self.discussions = discussions
        self.bodies = bodies
        self.api_folder = api_folder
        self.save_or_load_api = save_or_load_api
        self.methods = dict()
        self.log = settings.logger

    def extract_code_tag(self, body):
        '''
        extract all <code> blocks contained into <pre> tags
        If the <code> block is not inside a <pre> tag, this is not a code snippet
        '''

        codes = list()

        soup = BeautifulSoup(body, 'html.parser')

        exist_code = soup.find("pre")

        while exist_code is not None:

            children = exist_code.findChildren("code", recursive=False)

            for child in children:
                codes.append(child.text)

                new_condition = BeautifulSoup("<p></p>", 'html.parser')

                child.replaceWith(new_condition)

            new_code = exist_code.__str__().replace("<pre", "<pre_new", 1)

            new_code = "</pre_new".join(new_code.rsplit("</pre", 1))

            new_condition = BeautifulSoup(new_code, 'html.parser')
            exist_code.replaceWith(new_condition)

            # new_condition = BeautifulSoup("<p></p>", 'html.parser')
            # soup.find("pre").replaceWith(new_condition)
            exist_code = soup.find("pre")

        return codes

    def extract_methods(self):
        '''
        extract all methods from the codes
        You can save the methods for each discussion in api_methods.json or load them from that file
        '''

        count = 0
        methods = dict()

        if self.save_or_load_api.lower() == "save":

            for key in self.bodies.keys():
                body = self.bodies[key]
                codes = list()
                try:
                    codes = self.extract_code_tag(body)
                except Exception as e:
                    self.log.info("Error in api method similarity with key {} : {}".format(key, e))
                if len(codes) == 0:
                    # print("NO CODE")
                    methods[key] = list()
                    continue

                # print(len(codes))

                methods_curr = list()

                for code in codes:

                    try:

                        tree = ast.parse(code)
                        cc = CallCollector()
                        cc.visit(tree)
                        # print(cc.calls)
                        count += 1
                        methods_curr.extend([c.split(".")[-1] for c in
                                             cc.calls])  # we kept only the last part (e.g. os.listdir => listdir)

                    except Exception as e:
                        pass
                        # print("ERROR PARSING")

                not_null_methods = [k for k in methods_curr if len(k.strip()) > 0]

                # duplicate removal
                methods[key] = list(dict.fromkeys(not_null_methods))

            api_methods_file = open(os.path.join(self.api_folder, "api_methods.json"), "w")
            json.dump(methods, api_methods_file)
            api_methods_file.close()

        else:

            api_methods_file = open(os.path.join(self.api_folder, "api_methods.json"), "r")
            methods = json.load(api_methods_file)
            api_methods_file.close()

        self.methods = methods

    def initialize_api_method_similarity(self):
        '''
        initialize the function for similarity (by extracting/loading methods)
        '''
        self.extract_methods()

    def compute_api_method_similarity(self, query_file_name):
        '''
        given the query file, you can compute api method similarity
        '''
        f = FileManager(query_file_name)
        f.open_file_txt("r")
        code = f.read_file_txt()
        f.close_file()

        # print("code")

        tree = ast.parse("\n".join(code))
        cc = CallCollector()
        cc.visit(tree)
        # print(cc.calls)
        calls = [c.split(".")[-1] for c in cc.calls]  # we kept only the last part (e.g. os.listdir => listdir)

        methods_query = [k for k in calls if len(k.strip()) > 0]

        # duplicate removal
        methods_query = list(dict.fromkeys(methods_query))

        self.log.info("METHODS QUERY: {}".format(" ".join(methods_query)))

        api_similarity = dict()

        for key in self.methods.keys():
            method = self.methods[key]

            intersection = list(set(methods_query) & set(method))

            try:
                api_similarity[key] = len(intersection) / len(methods_query)
            except Exception as e:
                api_similarity[key] = 0

        return api_similarity
