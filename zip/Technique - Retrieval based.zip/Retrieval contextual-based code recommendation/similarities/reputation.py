import math

import utils.settings as settings


class Reputation:
    def __init__(self, avg_reputation, reputations, discussions):
        self.avg_reputation = avg_reputation
        self.reputations = reputations
        self.discussions = discussions
        self.user_reputations = dict()
        self.log = settings.logger

    def sigmoid(self, x):
        return 1 / (1 + math.exp(-x))

    def initialize_user_reputation(self):
        '''
        compute the value 1/(1+exp(avg(x) - x ))
        where avg(x) is the average score among all users and x is the score of the user who wrote the current question
        see Ponzanelli et al paper for further information
        '''
        user_reputations = dict()

        for k in self.reputations.keys():
            argument = self.reputations[k] - self.avg_reputation

            user_reputations[k] = self.sigmoid(argument)

        self.user_reputations = user_reputations

        # logistic_fun
        #
        # for k in self.scores.key()

    def compute_user_reputation(self):
        '''
        Return the user reputation of all the OwnerUserId of each question
        '''

        dict_question_reputation = dict()
        user_deleted = 0
        for k in self.discussions.keys():

            discussion = self.discussions[k]
            user_id = discussion.question.UserId
            try:
                dict_question_reputation[k] = self.user_reputations[user_id]
            except Exception as e:
                # this should not happen (we took care of that in the dataset)
                self.log.error("ERROR: the user is not present!")
                dict_question_reputation[k] = 1 / 2
                user_deleted += 1

        self.log.info("{} questions don't have any UserId as owner of the question".format(user_deleted))

        return dict_question_reputation

        # return self.user_reputations
