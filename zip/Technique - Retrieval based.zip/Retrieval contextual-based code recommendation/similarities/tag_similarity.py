import ast

import os
import json
import string

from file_manager import FileManager

import utils.settings as settings


class TagSimilarity:
    def __init__(self, discussions, bodies, tag_folder, save_or_load_tag):
        self.discussions = discussions
        self.tag_folder = tag_folder
        self.save_or_load_tag = save_or_load_tag
        self.bodies = bodies
        self.tags = dict()
        self.log = settings.logger

    def initialize_tag_similarity(self):
        self.extract_tags()

    def extract_tags(self):
        '''
        extract all tags from Question tags
        e.g <python><csv> => [python, csv]
        '''

        tags_dict = dict()

        if self.save_or_load_tag.lower() == "save":

            for key in self.discussions.keys():
                discussion = self.discussions[key]
                tags = discussion.question.Tags

                tags = tags.split(">")

                tags = self.split_compound_imports(tags)

                # remove all tags whose length is 0 or 1
                not_null_tags = [k for k in tags if len(k.strip()) > 1]

                # duplicate removal
                tags_dict[key] = list(dict.fromkeys(not_null_tags))

            tag_file = open(os.path.join(self.tag_folder, "tags.json"), "w")
            json.dump(tags_dict, tag_file)
            tag_file.close()

        else:

            tag_file = open(os.path.join(self.tag_folder, "tags.json"), "r")
            tags_dict = json.load(tag_file)
            tag_file.close()

        self.tags = tags_dict

    def get_imports(self, code):
        '''
        given the python snippet, it extract all imports (see README for further information)
        '''
        result = list()

        root = ast.parse(code)

        for node in ast.iter_child_nodes(root):
            if isinstance(node, ast.Import):
                module = []
            elif isinstance(node, ast.ImportFrom):
                module = node.module.split('.')
            else:
                continue


            for n in node.names:
                result.extend(module)
                result.append(n.name)

        result = self.split_compound_imports(result)

        result = [r for r in result if len(r.strip()) > 1]  # we excluded them if the length is 0 or 1


        # if len(result)>0:
        #     print(result)

        return result

    def split_compound_imports(self, imports_list):
        '''
        split compount tokens if they contain numbers or symbols.
        '''

        chars_to_remove = str(string.punctuation + string.digits)

        ttt = list()
        for tt in imports_list:
            for a in list(chars_to_remove):
                tt = tt.replace(a, "_")
            ttt.extend(tt.split("_"))

        res = [t.strip() for t in ttt if len(t.strip()) > 0]

        return res

    def compute_tag_similarity(self, query_file_name):
        '''
        compute the similarity between the imports in the query and the tag in each discussion
        '''
        f = FileManager(query_file_name)
        f.open_file_txt("r")
        code = f.read_file_txt()
        f.close_file()

        imports_query = self.get_imports("\n".join(code))

        # duplicate removal
        imports_query = list(dict.fromkeys(imports_query))

        self.log.info("TAGS QUERY: {}".format(" ".join(imports_query)))

        tag_similarity = dict()

        for key in self.tags.keys():
            tags_curr = self.tags[key]

            intersection = list(set(imports_query) & set(tags_curr))
            try:
                tag_similarity[key] = len(intersection) / len(imports_query)
            except Exception as e:
                tag_similarity[key] = 0

            # self.log.info("tags curr: {}".format(" ".join(tags_curr)))
            # self.log.info("similarity: {}".format(len(intersection) / len(imports_query)))

        return tag_similarity
