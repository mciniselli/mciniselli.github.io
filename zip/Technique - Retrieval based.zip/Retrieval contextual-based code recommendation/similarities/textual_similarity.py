import os

from bs4 import BeautifulSoup

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem.snowball import SnowballStemmer

import string

import keyword

import json

import tokenize

import numpy as np
import re

import utils.settings as settings


class TextualSimilarity:

    def __init__(self, discussions, bodies, idf_folder, save_or_load_idf, discussion_tokens_folder,
                 save_or_load_discussion_tokens):
        self.discussions = discussions
        self.bodies = bodies
        self.idf_folder = idf_folder
        self.save_or_load_idf = save_or_load_idf
        self.idf_dict = None  # IDF for each token
        self.count_dict = None  # number of documents each token occurs in
        self.discussion_tokens = None  # list with all (filtered) tokens for each discussion
        self.discussion_tokens_folder = discussion_tokens_folder
        self.save_or_load_discussion_tokens = save_or_load_discussion_tokens
        self.log = settings.logger

    def initialize_textual_similarity(self):
        '''
        Initialize all the object needed for compute textual similarity
        The function create self.discussion_tokens (a list that contains all(filtered) tokens for each discussion),
        self.idf_dict (a dict that contains for each token the specified IDF)
        self.count_dict (a dict that contains for each tokens the documents it occurs in)
        You can save them or load them all
        '''
        discussion_tokens = dict()

        if self.save_or_load_discussion_tokens.lower() == "save":

            for key in self.bodies.keys():
                body = self.bodies[key]
                words = list()
                try:
                    soup = BeautifulSoup(body, 'html.parser')

                    soup = self.remove_code_tag(soup)

                    text_cleaned = self.clean_code(soup)

                    text_cleaned = self.remove_punctuation(text_cleaned)

                    words = self.remove_stopwords_and_python_keyword(text_cleaned)

                    words = self.split_compound_tokens(words)

                    words = self.snowball_stemmer(words)
                except Exception as e:
                    self.log.info("Error in textual similarity with key {} : {}".format(key, e))

                discussion_tokens[key] = words

            discussion_tokens_file = open(os.path.join(self.discussion_tokens_folder, "discussion_tokens.json"), "w")
            json.dump(discussion_tokens, discussion_tokens_file)
            discussion_tokens_file.close()

        else:
            discussion_tokens_file = open(os.path.join(self.discussion_tokens_folder, "discussion_tokens.json"), "r")
            discussion_tokens = json.load(discussion_tokens_file)
            discussion_tokens_file.close()

        if self.save_or_load_idf.lower() == "save":
            count_dict, idf_dict = self.idf(discussion_tokens)

            count_file = open(os.path.join(self.idf_folder, "count_idf.json"), "w")
            json.dump(count_dict, count_file)
            count_file.close()

            idf_file = open(os.path.join(self.idf_folder, "idf.json"), "w")
            json.dump(idf_dict, idf_file)
            idf_file.close()

        else:

            count_file = open(os.path.join(self.idf_folder, "count_idf.json"), "r")
            count_dict = json.load(count_file)
            count_file.close()

            idf_file = open(os.path.join(self.idf_folder, "idf.json"), "r")
            idf_dict = json.load(idf_file)
            idf_file.close()

        self.idf_dict = idf_dict
        self.count_dict = count_dict
        self.discussion_tokens = discussion_tokens

    def compute_textual_similarity(self, query_file_name):
        '''
        compute the textual similarity between the query code and all the discussions
        using the cosine similarity among tf-idf vectors
        '''
        list_tokens = list()

        with open(query_file_name, 'rb') as f:
            tokens = tokenize.tokenize(f.readline)
            for token in tokens:
                list_tokens.append(token.string)

        list_tokens = list_tokens[1:]  # remove utf-8 tokens
        list_tokens = [t for t in list_tokens if len(t.strip()) > 0]  # remove empty tokens
        try:
            # remove the token used as a placeholder for the code to predict
            list_tokens.remove("'this line has to be removed'")
        except Exception as e:
            self.log.info("special token not found")

        # check if we need to remove some tokens do to the partial statements
        for token in list_tokens:
            if "this line has to be removed" in token:
                parts=token.split("|||")
                token_=parts[1].replace("TOKEN:", "")
                list_t=token_.split("|$|")
                list_t = [t.replace("'","").strip() for t in list_t if len(t.strip())>0]
                for t in list_t:
                    print("REMOVE FAKE TOKEN {}".format(t))
                    list_tokens.remove(t)
                list_tokens.remove(token)


        self.log.info("LIST TOKENS: {}".format((" ".join(list_tokens))))

        text_cleaned = [text.translate(str.maketrans('', '', string.punctuation)) for text in list_tokens]

        text_cleaned = " ".join(text_cleaned)

        words = self.remove_stopwords_and_python_keyword(text_cleaned)

        words = self.split_compound_tokens(words)

        words = self.snowball_stemmer(words)

        self.log.info("QUERY: {}".format(" ".join(words)))

        cosine_similarities = self.cosine_similarity(words, self.discussion_tokens, self.idf_dict)

        return cosine_similarities

    def remove_code_tag(self, soup):
        '''
        remove all <code> blocks into <pre> tags
        '''
        exist_code = soup.find("pre")

        while exist_code is not None:

            children = exist_code.findChildren("code", recursive=False)

            for child in children:
                new_condition = BeautifulSoup("<p></p>", 'html.parser')

                child.replaceWith(new_condition)

            new_code = exist_code.__str__().replace("<pre", "<pre_new", 1)

            new_code = "</pre_new".join(new_code.rsplit("</pre", 1))

            new_condition = BeautifulSoup(new_code, 'html.parser')
            exist_code.replaceWith(new_condition)

            # new_condition = BeautifulSoup("<p></p>", 'html.parser')
            # soup.find("pre").replaceWith(new_condition)
            exist_code = soup.find("pre")

        return soup

    def clean_code(self, soup):
        '''
        remove tags from html code
        '''
        html_code = soup.__str__()
        html_code_full = "<html>{}</html>".format(html_code)

        soup = BeautifulSoup(html_code_full, 'html.parser')
        return soup.get_text()

    def remove_punctuation(self, text):
        '''
        remove puncuation
        '''
        return text.translate(str.maketrans('', '', string.punctuation))

    def remove_stopwords_and_python_keyword(self, text):
        '''
        The function removed all english stopwords (using NLTK) and all python keywords
        '''

        word_list = word_tokenize(text)

        filtered_words = [word for word in word_list if word not in stopwords.words('english')]

        filtered_words = [word for word in filtered_words if word not in keyword.kwlist]

        return filtered_words

    def split_compound_tokens(self, token_list):
        '''
        split compount tokens if they contain _ or a digit.
        '''

        # replace digits with _
        tokens = [re.sub('\d', '_', t) for t in token_list]

        result = list()

        for t in tokens:
            result.extend(t.split("_"))

        result = [r for r in result if len(r.strip()) > 0]
        return result

    def snowball_stemmer(self, words):
        '''
        The list of tokens is processed by a stemmer
        '''
        # the stemmer requires a language parameter
        snow_stemmer = SnowballStemmer(language='english')

        # stem's of each word
        stem_words = []
        for w in words:
            x = snow_stemmer.stem(w)
            stem_words.append(x)

        return stem_words

    #################################################
    ## TF-IDF-COSINE SIMILARITY RELATED FUNCTIONS  ##
    #################################################

    def tf(self, word, list_of_words):
        return list_of_words.count(word) / float(len(list_of_words))

    def tf_list(self, query, document):
        '''
        apply tf to a list of tokens
        '''
        return [self.tf(word, document) for word in query]

    def idf(self, discussion_tokens):
        '''
        return the number of discussion each term compare in
        '''
        dict_count = dict()
        dict_idf = dict()

        for key in discussion_tokens.keys():

            discussion_token = discussion_tokens[key]

            # remove duplicates
            no_duplicates = list(dict.fromkeys(discussion_token))

            for token in no_duplicates:
                if token in dict_count.keys():
                    dict_count[token] += 1
                else:
                    dict_count[token] = 1

        num_discussions = len(discussion_tokens.keys())

        for k in dict_count.keys():
            dict_idf[k] = 1 + np.log(num_discussions / dict_count[k])

        return dict_count, dict_idf

    def tf_idf_document(self, word, document, dict_idf):
        idf = 1
        if word in dict_idf.keys():
            idf = dict_idf[word]

        return self.tf(word, document) / idf

    def tf_idf_all_documents(self, word, documents, dict_idf):
        list_tf_idf = list()
        for document in documents:
            list_tf_idf.append(self.tf_idf_document(word, document, dict_idf))

        return list_tf_idf

    def return_idf(self, word, dict_idf):
        if word not in dict_idf.keys():
            return 1

        return dict_idf[word]

    def cosine_similarity(self, query, discussion_tokens, dict_idf):
        '''
        Compute cosine similarity among tf-idf vectors
        '''
        tf_query = [self.tf(word, query) for word in query]
        idf_query = [self.return_idf(word, dict_idf) for word in query]

        tf_idf_query = [x * y for x, y in zip(tf_query, idf_query)]

        cosine_similarities = dict()

        for i, key in enumerate(discussion_tokens.keys()):

            discussion_token = discussion_tokens[key]

            if len(discussion_token) == 0:
                self.log.info("NO TOKENS FOR KEY {}".format(key))
                cosine_similarities[key] = 0
                continue

            # print("Document {}".format(i))
            tf_document = self.tf_list(query, discussion_token)
            tf_idf_document = [x * y for x, y in zip(tf_document, idf_query)]

            norm_document = np.sqrt(np.dot(tf_idf_document, tf_idf_document))
            norm_query = np.sqrt(np.dot(tf_idf_query, tf_idf_query))

            dot_product = np.dot(tf_idf_query, tf_idf_document)

            if dot_product == 0:
                cosine_similarity = 0
            else:
                cosine_similarity = dot_product / (norm_query * norm_document)

            cosine_similarities[key] = cosine_similarity

        return cosine_similarities
