import math


class QuestionScore:
    def __init__(self, avg_score, scores):
        self.avg_score = avg_score
        self.scores = scores
        self.question_scores = None

    def sigmoid(self, x):
        '''
        compute the sigmoid function
        '''
        return 1 / (1 + math.exp(-x))

    def initialize_question_scores(self):
        '''
        compute the value 1/(1+exp(avg(x) - x ))
        where avg(x) is the average score among all question and x is the score of the current question
        see Ponzanelli et al paper for further information
        '''
        question_scores = dict()

        for k in self.scores.keys():
            argument = self.scores[k] - self.avg_score

            question_scores[k] = self.sigmoid(argument)

        self.question_scores = question_scores


    def compute_question_scores(self):
        return self.question_scores
