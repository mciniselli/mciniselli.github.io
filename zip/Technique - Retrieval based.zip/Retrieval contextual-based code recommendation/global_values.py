
from file_manager import FileManager

import numpy as np

class GlobalValue:
    '''
    this class was created to analyze the global values, you don't need to run it
    '''
    def __init__(self, score_file, reputation_file):
        self.score_file=score_file
        self.reputation_file=reputation_file

    def compute_global_values(self):

        # read scores file
        f = FileManager(self.score_file)
        f.open_file_txt("r")
        scores = f.read_file_txt()
        f.close_file()

        print("{} SCORES".format(len(scores)-1))

        scores=scores[1:]
        scores=[int(s) for s in scores]

        print("ORIGINAL")

        print(np.mean(scores))
        print(np.min(scores))
        print(np.max(scores))
        print(np.median(scores))

        from collections import Counter
        c=Counter(scores)

        common=c.most_common(10)

        for comm in common:
            print(comm)

        # scores.sort()
        #
        # print("NO OUTLIER")
        #
        # scores=scores[1000:-1000]
        #
        # print(np.mean(scores))
        # print(np.min(scores))
        # print(np.max(scores))
        # print(np.median(scores))
        #
        # print("NO ZERO")
        #
        # scores=[s for s in scores if s != 0]
        #
        # print(np.mean(scores))
        # print(np.min(scores))
        # print(np.max(scores))
        # print(np.median(scores))



        # reputation

        f = FileManager(self.reputation_file)
        f.open_file_txt("r")
        reputations = f.read_file_txt()
        f.close_file()

        print("REPUTATION {}".format(len(reputations)-1))

        reputations=reputations[1:]
        reputations=[int(s) for s in reputations]

        print("ORIGINAL")

        print(np.mean(reputations))
        print(np.min(reputations))
        print(np.max(reputations))
        print(np.median(reputations))

        from collections import Counter
        c=Counter(reputations)

        common=c.most_common(10)

        for comm in common:
            print(comm)

        # reputations.sort()
        #
        # print("NO OUTLIER")
        #
        # reputations=reputations[1000:-1000]
        #
        # print(np.mean(reputations))
        # print(np.min(reputations))
        # print(np.max(reputations))
        # print(np.median(reputations))
        #
        # print("NO ONE")
        #
        # reputations=[s for s in reputations if s != 1]
        #
        # print(np.mean(reputations))
        # print(np.min(reputations))
        # print(np.max(reputations))
        # print(np.median(reputations))