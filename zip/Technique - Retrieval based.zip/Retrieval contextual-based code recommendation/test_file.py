
#### # test functions

def test_code_removal():

    ## test for <pre><code> removal

    body="""<p>I've <pre class="lang-py prettyprint-override"><p> PRESENT </p></pre> got <pre> AAAA <code> BBB </code> </pre> a menu in Python. That part was easy. I'm using <code>raw_input()</code> to get the selection from the user. </p>&#xA;&#xA;<p>The problem is that <code>raw_input</code> (and input) require the user to press <kbd>Enter</kbd> after they make a selection. Is there any way to make the program act immediately upon a keystroke? Here's what I've got so far:</p>&#xA;&#xA;<pre><code>import sys&#xA;print hello</code></pre>&#xA;&#xA;<p>It would be great to have something like</p>&#xA;&#xA;<pre><code>print menu&#xA;while lastKey = "":&#xA;    lastKey = check_for_recent_keystrokes()&#xA;if "1" in lastKey: #do stuff...&#xA;</code></pre>&#xA;"""

    t=TextualSimilarity()

    soup = BeautifulSoup(body, 'html.parser')

    print(soup.__str__())

    t.remove_code_tag(soup)

    text_cleaned = t.clean_code(soup)

    print("CLEANED")

    print(text_cleaned)

def test_cosine_similarity():

    ## test for cosine similarity

    t=TextualSimilarity()

    discussion_tokens=list()

    discussion_tokens.append("The game of life is a game of everlasting learning".split(" "))
    discussion_tokens.append("The unexamined life is not worth living".split(" "))
    discussion_tokens.append("Never stop learning".split(" "))

    count_dict, idf_dict=t.idf(discussion_tokens)

    query="life learning".split(" ")
    t.cosine_similarity(query, discussion_tokens, idf_dict)


def test_whole_process(questions_path):
    # read questions file

    fields_questions = ["Id", "PostTypeId", "ParentId", "CreationDate", "Score", "Body", "OwnerUserId", "Title", "Tags",
                        "AnswerCount", "CommentCount", "ClosedDate"]

    separator = "|!--!|"

    f = FileManager(questions_path)
    f.open_file_csv("r", fields_questions)
    questions = f.read_csv_list(separator=separator)
    f.close_file()

    print(len(questions))
    print(questions[0])
    print("_____")

    discussion_tokens = list()

    t = TextualSimilarity()

    for question in questions:
        body = (question.split(separator)[5])

        soup = BeautifulSoup(body, 'html.parser')

        print("ORIGINAL CODE")
        print(soup.__str__())

        soup = t.remove_code_tag(soup)

        print("PARSED CODE")

        text_cleaned = t.clean_code(soup)

        print(text_cleaned)

        print("REMOVED STOPWORDS AND PYTHON KEYWORDS")

        words = t.remove_stopwords_and_python_keyword(text_cleaned)

        print(str(words))

        print("REMOVE COMPOUND TOKENS")

        words = t.split_compound_tokens(words)

        print(str(words))

        print("STEMMING")

        words = t.snowball_stemmer(words)

        print(str(words))

        print("________________")

        discussion_tokens.append(words)

    count_dict, idf_dict = t.idf(discussion_tokens)

    query = "login zip".split(" ")
    t.cosine_similarity(query, discussion_tokens, idf_dict)

def compute_cosine_similarity_ORIGINAL(query, discussions_class, idf_folder, save_or_load):

    '''
    # compute cosine similarity. The computation of tf-idf require a huge amount of time, so we can save it into @idf_folder
    You can choose to save it (@save_or_load = "save") or load it (@save_or_load = "load")

    '''

    discussions = discussions_class.discussions
    bodies = discussions_class.bodies

    discussion_tokens = list()

    t = TextualSimilarity(discussions, bodies, idf_folder, save_or_load, query)

    for key in bodies.keys():
        body = bodies[key]

        soup = BeautifulSoup(body, 'html.parser')

        # print("ORIGINAL CODE")
        # print(soup.__str__())

        soup = t.remove_code_tag(soup)

        # print("PARSED CODE")

        text_cleaned = t.clean_code(soup)

        # print(text_cleaned)
        # print("REMOVE PUNCTUATION")

        text_cleaned = t.remove_punctuation(text_cleaned)

        # print(text_cleaned)
        # print("REMOVED STOPWORDS AND PYTHON KEYWORDS")

        words = t.remove_stopwords_and_python_keyword(text_cleaned)

        # print(str(words))
        # print("REMOVE COMPOUND TOKENS")

        words = t.split_compound_tokens(words)

        # print(str(words))
        # print("STEMMING")

        words = t.snowball_stemmer(words)

        # print(str(words))
        # print("________________")

        discussion_tokens.append(words)

    if save_or_load.lower() == "save":
        count_dict, idf_dict = t.idf(discussion_tokens)

        count_file=open(os.path.join(idf_folder, "count_idf.json"), "w")
        json.dump(count_dict, count_file)
        count_file.close()

        idf_file=open(os.path.join(idf_folder, "idf.json"), "w")
        json.dump(idf_dict, idf_file)
        idf_file.close()

    else:

        count_file = open(os.path.join(idf_folder, "count_idf.json"), "r")
        count_dict=json.load(count_file)
        count_file.close()

        idf_file=open(os.path.join(idf_folder, "idf.json"), "r")
        idf_dict=json.load(idf_file)
        idf_file.close()

    t.cosine_similarity(query, discussion_tokens, idf_dict)