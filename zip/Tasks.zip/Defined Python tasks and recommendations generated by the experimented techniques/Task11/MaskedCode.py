filename = input('Enter a file name: ')

def print_senders(filename):

	count = 0

	fhand = open(filename, 'r')
	for line in fhand:
		if line.startswith('From:'):
			print(line.<TO COMPLETE>
			count+=1

	print("There were", count, "lines in the file with From as first word")