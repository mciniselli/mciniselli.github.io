1: split(' ')[1])
2: split(',')[0])
3: .join(','))