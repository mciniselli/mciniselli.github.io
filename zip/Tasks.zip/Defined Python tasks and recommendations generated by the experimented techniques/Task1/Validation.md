1: targetStream.download(filename=name)
2: print(targetStream)
3: targetStream.check_if_exists(video_url)