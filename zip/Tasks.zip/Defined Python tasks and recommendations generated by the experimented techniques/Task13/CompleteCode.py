n_lines = int(input("enter how many lines you want to print: "))

def print_floyd(n_lines):
	num=1
	for row in range(1, n_lines+1):
		for col in range(1, row+1):
			print(num, end="")
			num=num+1
		print()