1: ignores
2: start_comment
3: state