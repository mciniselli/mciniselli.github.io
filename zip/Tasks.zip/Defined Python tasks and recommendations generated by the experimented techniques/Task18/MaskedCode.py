def get_comment_ranges(source):    
    #State list:
    # 0: Normal code
    # 1: "/" found (possible start of single-line or multi-line comment)
    # 2: "/*" found (in multi-line comment)
    # 3: "*" found (maybe end of multi-line comment)
    
    start_comment = 0;
    state = 0;
        
    ignores = []
    for i in range(0, len(source)):
        current = source[i]
        if state == 0:
            if current == '/':
                state = 1

        elif state == 1:
            if current == '*':
                state = 2
                start_comment = i - 1
            elif current == '/':
                state = 4
                start_comment = i - 1
            else:
                state = 0
                
        elif state == 2:
            if current == '*':
                state = 3
            
        elif state == 3:
            if current == '/':
                ignores.append((start_comment, i))
                state = 0
            elif current != '*':
                state = 2;

        elif state == 4:
            if current == '\n':
                ignores.append((start_comment, i))
                state = 0
    
    if state == 4:
        ignores.append((start_comment, len(source)))
    return <TO COMPLETE>
