1:  tokens = name.split(".")
    name_no_extension = name.replace("." + tokens[len(tokens)-1], "")
    if has_date(name_no_extension):
        print(name_no_extension)
2:  name_no_extension = name.replace(".", "").substring(-3)
    if has_date(name_no_extension):
        print(name_no_extension)
3:  tokens = name.split(".")
    name_no_extension = name.replace("/" + tokens[-1], "")
    if has_date(name_no_extension):
        print(name_no_extension)