import random


def mask_tokens(sentence):
    words = sentence.split()
    if len(words) < 2:
        return sentence

    # Compute the number of words to mask
    n_words_to_mask = int(round(len(words) * 0.15))
    if n_words_to_mask < 1:
        n_words_to_mask = 1

    # Randomly select the words to mask
    to_mask = random.sample(range(len(words)), n_words_to_mask)

    # Mask the string and return it
    to_return = ""
    for i in range(len(words)):
        if i in to_mask:
            to_return += " <MASK>"
        else:
            to_return += " " + words[i]

    return to_return



print(mask_tokens("This is an example of sentence"))