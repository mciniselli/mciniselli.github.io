1: ftp.quit()
2: f.close()
3: ftp.connect()