1:  play_list.insert(pos, item)
	pos += 1
2:  if item != play_list[pos]:
        continue
	pos += 1
3:  play_list.insert(len(song_list) - pos, item)
    pos += 1