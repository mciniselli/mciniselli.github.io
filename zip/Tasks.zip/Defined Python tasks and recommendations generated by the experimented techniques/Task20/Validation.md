1: correct(), end=" ", flush=True)
2: TextBlob.correct(), end=" ", flush=True)
3: upper(), end=" ", flush=True)