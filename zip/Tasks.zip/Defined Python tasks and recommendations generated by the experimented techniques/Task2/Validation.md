1: airports_in_asia.append(line[1])
2: airports_in_asia.add(line[0])
3: airports_in_asia.append(line.substring(0,1))