import csv

def get_csv_column_occurrence(filename: str, column_name: str, term: str) -> int:
    count = 0
    in_file = open(filename, 'r', newline='', encoding="utf-8")
    csv_in_file = csv.DictReader(in_file, delimiter=',')
    for line in <TO COMPLETE>
        if term in line[column_name]:
            count += 1
    return count

if __name__ == '__main__':
    print('{}'.format(get_csv_column_occurrence('input.csv', 'col3', 'om')))