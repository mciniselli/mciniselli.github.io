1: csv_in_file:
2: csv_in_file.split():
3: range(1, len(csv_in_file)):