class SlidingWindowWithOverlap:
    def __init__(self, size=20, overlap=10):
        self._observations = []
        self._size = size
        self._overlap = overlap
    
    def add(self, value):
        if len(self._observations) == self._size:
            while len(self._observations) > self._overlap:
                self._observations.pop(0)
                
        self._observations.append(value)
    
    def sum(self):
        if len(self._observations) < self._size:
            return None
        else:
            return sum(self._observations)
