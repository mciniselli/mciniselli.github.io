def distance(a, b):
    return ((a[0] - b[0])**2 + (a[1] - b[1])**2) ** 0.5
    
def find_centers(points, k):
    n_points = len(points)
    distances = [float('inf') for i in range(n_points)]
    centers = [0]
    for i in range(n_points):
        if i in centers:
            distances[i] = 0
        else:
            distances[i] = min(distances[i], distance(points[i], points[0]))
    
    while len(centers) < k:
        maxDistance=0
        for i in range(n_points):
            <TO COMPLETE>
                candidate = i
                maxDistance = distances[i]
        centers.append(candidate)
        
        for i in range(n_points):
            if i in centers:
                distances[i] = 0
            else:
                distances[i] = min(distances[i], distance(points[i], points[candidate]))
    
    return centers
