import csv

def get_csv_column_average(filename: str, column_name: str) -> float:
    count = sum = 0
    in_file = open(filename, 'r', newline='', encoding="utf-8")
    csv_in_file = csv.DictReader(in_file, delimiter=',')
    for line in csv_in_file:
        sum += float(line[column_name])
        count += 1
    return float(sum / count)


if __name__ == '__main__':
    print('{:.3}'.format(get_csv_column_average('input.csv', 'col2')))