1:  vid_src = article.find('iframe', class_='youtube-player')['src']
    vid_id = vid_src.split('/')[4]
    vid_id = vid_id.split('?')[0]
    yt_link = f'https://youtube.com/watch?v={vid_id}'
2:  vid_src = article.find('iframe')['youtube-player']
    vid_id = vid_id.split('?')[0]
    yt_link = f'https://youtube.com/watch?v={vid_id}'
3:  vid_id = article.find('iframe', class_='youtube-player')['vid_id']
    yt_link = f'https://youtube.com/watch?v={vid_id}'