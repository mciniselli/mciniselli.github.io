1: pdfkit.from_string(title, desktop_path + 'ICSE.pdf')
2: html.create_pdf(title, 'desktop_path/ICSE.pdf')
3: pdfkit.create(title, 'desktop_path/ICSE.pdf')