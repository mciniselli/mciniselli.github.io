1: show()
2: create_pdf("out.pdf")
3: write()