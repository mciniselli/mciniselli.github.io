import numpy as np
import cv2
from matplotlib import pyplot as plt
from PIL import Image, ImageFilter

image_path='cm.jpg'

def plot_image(image_path):
	image = cv2.imread(image_path) # reads the image
	image2 = cv2.cvtColor(image, cv2.COLOR_HSV2BGR)
	image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2GRAY)
	figure_size = 9
	new_image = cv2.blur(image2,(figure_size, figure_size))
	plt.figure(figsize=(11,6))
	plt.subplot(121), plt.imshow(image2, cmap='gray'),plt.title('Original')
	plt.xticks([]), plt.yticks([])
	plt.subplot(122), plt.imshow(new_image, cmap='gray'),plt.title('Grayscale filter')
	plt.xticks([]), plt.yticks([])
	plt.<TO COMPLETE>
