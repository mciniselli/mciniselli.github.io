import smtplib, ssl

def read_creds():
    user = passw = ""
    with open("credentials.txt", "r") as f:
        file = f.readlines()
        user = file[0].strip()
        passw = file[1].strip()

    return user, passw


port = 465

message = """\
Subject: Python Email Tutorial

This is from python!

Tech With Tim
"""

def send_message(port, message):
	sender, password = read_creds()

	receive = sender
	context = ssl.create_default_context()

	print("Starting to send")
	with smtplib.SMTP_SSL("smtp.gmail.com", port, context=context) as server:
	    <TO COMPLETE>