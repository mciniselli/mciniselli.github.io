1: data.decode('utf-8')
2: data.send()
3: resize()