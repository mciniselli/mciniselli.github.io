1: 	cursor.execute("CREATE DATABASE experiment")
2: 	connector.run("CREATE DATABASE experiment")
3: 	cursor.create_table("experiment")