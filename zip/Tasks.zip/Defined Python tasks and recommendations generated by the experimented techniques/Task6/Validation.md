1: return num3
2: return (num3 > num2)
3: if num2 >= num3: return num2