# DL-based contextual code completion

We used T5 models as representative of DL model.

### Preliminary step
The training of the model is done on a TPU instance of **Colab**.
A GCS Bucket is mandatory.
To Set up a new GCS Bucket for training and fine-tuning a T5 Model, please follow the guide provided by Google [here](https://cloud.google.com/storage/docs/quickstart-console).

### Pipeline
* ##### Dataset

    You can find the datasets used for pretraining and fine-tuning the models [here](<LINK> Omitted for double blind review).
    
* ##### Tokenizer

    We trained the tokenizer using the script in `Tokenizer` folder.
    ```
    python3 tokenizer.py --input=<input_file> --model_prefix=code --vocab_size=32000 --bos_id=-1  --eos_id=1 --unk_id=2 --pad_id=0
    ```
    Where:
    - input: the path for the txt file containing the code to tokenize 
    - model_prefix: the prefix for the tokenizer (e.g. code => it generates code.vocab and code.model)
    - vocab_size: the size of the vocabulary
    - bos_id: begin of sentence id (this changes only the order or the tokens stored in the vocabulary
    - eos_id: end of sentence id (this changes only the order or the tokens stored in the vocabulary)
    - unk_id: unknown token id (this changes only the order or the tokens stored in the vocabulary)
    - pad_id: padding id (this changes only the order or the tokens stored in the vocabulary)
    
    You can find the tokenizer in `Pretraining/tokenizer_model` folder and the dataset for the tokenizer training [here](<LINK> Omitted for double blind review).
    
* ##### Pretraining
    
    For pretraining the model you can find the notebook **pretrain.ipynb** in the `Pretraining` folder. 
    The notebook has comments that explain how to run it. We run the model for 400k steps
    You can also find the gin file for config in the `configuration_file` folder and the trained tokenizer in the `tokenizer_model` folder.
    The pretrained model is available [here](<LINK> Omitted for double blind review)
    
* ##### Hyper Parameter tuning

    We did hyper parameter tuning to find the best model for the finetuning.
    We tested 4 configuration and trained the model for 100k steps.
    The configurations are the following:
    - constant learning rate (lr = 0.001)
    - Inverse Square Root (warmup_steps = 10000)
    - slanted (cut_fraction=0.1, ratio=32, max_learning_rate=0.01, start_step=0)
    - polynomial learning rate (starter_learning_rate=0.01, end_learning_rate=1e-6, decay_step=10000, power=0.5)
    
    You can find the commented notebooks in `HP_Tuning/pretraining_script`.
    The configuration files for each HP tuning are in `HP_Tuning/configuration_files`.
    You can find the script to evaluate the performances in the `HP_Tuning/evaluation` folder.
    ```
    python3 perfect_predictions.py --folder <folder_with_prediction> 
    ```
    In the **--folder** you have to save all the files generated during the evaluation by tensorflow.
    You can find [here](<LINK> Omitted for double blind review) the HP tuning models and the files for the predictions
    
    We trained the model for 50k steps and we evaluated the models: the best model was **ISR**!
    
* ##### Finetuning

    To **evaluate the performance** of each model we used a beam size of 1.
    We finetuned the model for 600k steps using the finetuning dataset.
    [Here](<LINK> Omitted for double blind review) you can find the finetuned model.
    
    You can finetune and create the prediction file for evaluating the model by running the **Fine_tuning.ipynb** notebook in `Finetuning` folder (check the comments in the notebook).
    For the evaluation you have to load on the Bucket the input file containing the methods you want to predict and use the path of this file as the **input_file** in the predict method.
     
    The folder contains also perfect_prediction.py file to evaluate the model.   
    You can compute the **number of perfect predictions** running:
    ```
    python3 perfect_predictions.py --input_path <path_to_input_file>  --target_path <path_to_target_file> --prediction_path <path_to_prediction_file>
    ```
    Where
    - input_path contains the file you want to predict
    - target_path contains the file with the correct value that the model should predict
    - prediction_path contains the file with the T5 predictions
        
     You can find the finetuned model and the predictions [here](<LINK> Omitted for double blind review)
     The model achieved 29.35\% of perfect predictions.

## License
This software is licensed under the MIT License.


   
    
